export const endPoints = {
  baseUrl: "https://ecommerce-playground.lambdatest.io",
  login: "https://ecommerce-playground.lambdatest.io/index.php?route=account/login",
  register: "https://ecommerce-playground.lambdatest.io/index.php?route=account/register",
  account: "https://ecommerce-playground.lambdatest.io/index.php?route=account/account"
};
