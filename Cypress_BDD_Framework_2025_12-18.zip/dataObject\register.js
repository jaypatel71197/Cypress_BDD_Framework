export default class Register {
  firstName;
  lastName;
  email;
  password;
  confirmPassword;
  phone;
}
